from flask import Flask, render_template, request, session, redirect
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
import json
import os
import math
from datetime import datetime


with open('config.json', 'r') as c:
    params = json.load(c)["params"]


local_server = True
app = Flask(__name__)
if(local_server):
    app.config['SQLALCHEMY_DATABASE_URI'] = params['local_uri']
else:
    app.config['SQLALCHEMY_DATABASE_URI'] = params['prod_uri']

db = SQLAlchemy(app)



class Nodes(db.Model):
    ip = db.Column(db.String(80), nullable=False)
    type = db.Column(db.String(80), nullable=False)
    model = db.Column(db.String(80), nullable=False)
    adminUser = db.Column(db.String(80), nullable=False)
    adminPassword = db.Column(db.String(80), nullable=False)
    rootUser = db.Column(db.String(80), nullable=False)
    rootPassword = db.Column(db.String(80), nullable=False)


@app.route('/edit/<string:sno>', methods=['GET', 'POST'])
def add_data(sno):
    # Get data from
    ip = db.Column(db.String(80), nullable=False)
    type = db.Column(db.String(80), nullable=False)
    model = db.Column(db.String(80), nullable=False)
    adminUser = db.Column(db.String(80), nullable=False)
    adminPassword = db.Column(db.String(80), nullable=False)
    rootUser = db.Column(db.String(80), nullable=False)
    rootPassword = db.Column(db.String(80), nullable=False)
    date = datetime.now()

    if sno == '0':
        node = Nodes(ip=ip, type=type, model=model, adminUser=adminUser, adminPassword=adminPassword, rootUser=rootUser, rootPassword=rootPassword, date=date)
        db.session.add(node)
        db.session.commit()
    else:
        node = Nodes.query.filter_by(sno=sno).first()
        Nodes.ip = ip
        Nodes.type = type
        Nodes.model = model
        Nodes.adminUser = adminUser
        Nodes.adminPassword = adminPassword
        Nodes.rootUser = rootUser
        Nodes.rootPassword = rootPassword
        Nodes.date = datetime.now()
        db.session.commit()
    return redirect("/")



#  `sno` int(11) NOT NULL,
# --   `ip` text NOT NULL,
# --   `type` text NOT NULL,
# --   `model` text NOT NULL,
# --   `adminUser` text NOT NULL,
# --   `adminPassword` text NOT NULL,
# --   `rootUser` text NOT NULL,
# --   `rootPassword` text NOT NULL,
# --   `date`


@app.route("/")
def home():
    return render_template('index.html')


@app.route('/deployment')
def deployment():
    return render_template('deployment.html')


@app.route('/topology')
def topology():
    return render_template('topology.html')

@app.route('/monitor')
def monitor():
    return render_template('monitor.html')

app.run(debug=True)
