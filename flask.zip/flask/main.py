from flask import Flask, render_template, request
from flask_pymongo import MongoClient

app = Flask(__name__)


# Set up MongoDB connection
# client = MongoClient('mongodb://localhost:27017/')
# db = client['ISE']
# collection = db['Node']
#
#
# @app.route('/add_data', methods=['POST'])
# def add_data():
#     # Get data from request
#     data = request.json
#
#     # Insert data into MongoDB
#     collection.insert_one(data)
#
#     return 'Data added to MongoDB'


@app.route("/")
def home():
    return render_template('index.html')


@app.route('/deployment')
def deployment():
    return render_template('deployment.html')


@app.route('/topology')
def topology():
    return render_template('topology.html')

@app.route('/monitor')
def monitor():
    return render_template('monitor.html')

app.run(debug=True)
